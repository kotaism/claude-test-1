(function(){
  const $ = id => document.getElementById(id);
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const hudLeft = $('hudLeft'), hudRight = $('hudRight');
  const screenEl = $('screen');
  let app = 'home';

  function setHud(left, rightParts){
    hudLeft.textContent = left || '';
    hudRight.innerHTML = '';
    (rightParts || []).forEach(t => { const s = document.createElement('span'); s.textContent = t; hudRight.appendChild(s); });
  }
  const PANELS = ['frogStart','frogDialog','snakeMenu','dialog','rpsSetup','rpsChoose','rpsHandoff','rpsArena','rpsMatch'];
  function only(...ids){ PANELS.forEach(p => { $(p).hidden = !ids.includes(p); }); }
  function focusLater(el){ setTimeout(() => el && el.focus({preventScroll:true}), 0); }
  function blurActive(){ if (document.activeElement && document.activeElement.blur) document.activeElement.blur(); }

  function storeGet(key, fallback){
    try { const v = localStorage.getItem(key); return v ? (JSON.parse(v) ?? fallback) : fallback; } catch(e){ return fallback; }
  }
  function storeSet(key, val){ try { localStorage.setItem(key, JSON.stringify(val)); } catch(e){} }

  /* generic selectable list */
  function makeList(ul, items, onPick, onSelect){
    const api = { index:0, items };
    api.render = (focus) => {
      [...ul.querySelectorAll('button')].forEach((b,i) => b.classList.toggle('sel', i === api.index));
      onSelect && onSelect(api.index);
      if (focus){ const b = ul.querySelectorAll('button')[api.index]; if (b) b.focus({preventScroll:true}); }
    };
    api.build = () => {
      ul.innerHTML = '';
      api.items.forEach((it, i) => {
        const li = document.createElement('li'), b = document.createElement('button');
        b.type = 'button';
        b.innerHTML = '<span class="nm"></span><span class="rec"></span>';
        if (it.icon) b.querySelector('.nm').innerHTML = '<svg aria-hidden="true"><use href="#' + it.icon + '"/></svg>';
        b.querySelector('.nm').appendChild(document.createTextNode(it.label()));
        b.querySelector('.rec').textContent = it.extra ? it.extra() : '';
        b.addEventListener('click', () => { api.index = i; onPick(i); });
        b.addEventListener('mouseenter', () => { api.index = i; api.render(false); });
        b.addEventListener('focus', () => { api.index = i; api.render(false); });
        li.appendChild(b); ul.appendChild(li);
      });
      api.render(false);
    };
    api.move = (d) => { api.index = (api.index + d + api.items.length) % api.items.length; api.render(true); };
    return api;
  }

  /* =================== VIEWS + HOME =================== */
  const mainCanvas = $('canvas');
  const darkMQ = window.matchMedia('(prefers-color-scheme: dark)');
  const isDark = () => document.documentElement.dataset.theme === 'dark' || (document.documentElement.dataset.theme !== 'light' && darkMQ.matches);
  function resizeCanvas(){
    const r = screenEl.getBoundingClientRect(), dpr = window.devicePixelRatio || 1;
    if (!r.width || !r.height) return;
    const w = Math.round(r.width*dpr), h = Math.round(r.height*dpr);
    if (mainCanvas.width !== w || mainCanvas.height !== h){ mainCanvas.width = w; mainCanvas.height = h; }
  }
  const HINTS = {
    snake:'Steuern mit Pfeiltasten oder WASD. Leertaste pausiert, Esc öffnet die Modi.',
    rps:'Wähle mit 1, 2, 3 oder mit den Pfeiltasten und Enter. Esc geht einen Schritt zurück.',
    frog:'Laufen mit Pfeiltasten oder A und D, springen mit Leertaste oder Pfeil hoch. P pausiert.'
  };
  const A_LABEL = { snake:'OK', rps:'OK', frog:'Sprung' };
  function setView(game){
    document.body.dataset.view = game ? 'game' : 'home';
    if (game) document.body.dataset.game = game; else delete document.body.dataset.game;
    $('homeView').hidden = !!game;
    $('gameView').hidden = !game;
    if (game){
      $('hint').textContent = HINTS[game];
      $('aLabel').textContent = A_LABEL[game];
      $('pauseBtn').hidden = game === 'rps';
    }
    resizeCanvas();
    requestAnimationFrame(resizeCanvas);
  }
  function enter(game){ app = game; setView(game); }

  const GAMES = [
    { open: () => Snake.openMenu() },
    { open: () => RPS.openSetup() },
    { open: () => Frog.openStart() }
  ];
  const tiles = [...document.querySelectorAll('.gtile')];
  let homeIndex = 0;
  tiles.forEach((t, i) => {
    t.addEventListener('click', () => { homeIndex = i; GAMES[i].open(); });
    t.addEventListener('focus', () => { homeIndex = i; });
  });
  function homeStats(){
    const sb = storeGet('snake-bests', {}) || {};
    const best = Math.max(0, ...Object.values(sb).map(Number).filter(n => !isNaN(n)));
    $('statSnake').textContent = best ? 'Bester Lauf: ' + best + (best === 1 ? ' Apfel' : ' Äpfel') : 'Noch kein Rekord';
    const rs = storeGet('rps-stats', { wins:0, losses:0 }) || { wins:0, losses:0 };
    $('statRps').textContent = (rs.wins + rs.losses) ? 'Gegen den Bot: ' + rs.wins + ' zu ' + rs.losses : 'Noch nicht gespielt';
    const fp = storeGet('frog-progress', { unlocked:1 }) || { unlocked:1 };
    $('statFrog').textContent = 'Level ' + Math.min(5, fp.unlocked || 1) + ' von 5 freigeschaltet';
  }
  function goHome(){
    if (app === 'snake') Snake.leave();
    if (app === 'rps') RPS.leave();
    if (app === 'frog') Frog.leave();
    app = 'home';
    only();
    setView(null);
    homeStats();
    focusLater(tiles[homeIndex]);
  }

  /* =================== SNAKE =================== */
  const Snake = (function(){
    const N = 17;
    const DIRS = { up:{x:0,y:-1}, down:{x:0,y:1}, left:{x:-1,y:0}, right:{x:1,y:0} };
    const MODES = [
      { id:'classic',  name:'Klassisch',  desc:'Wände und der eigene Schwanz sind tödlich.', start:150, min:70, dec:3 },
      { id:'portal',   name:'Ohne Wände', desc:'Am Rand kommst du auf der anderen Seite wieder heraus. Dein Schwanz bleibt tödlich.', wrap:true, start:150, min:70, dec:3 },
      { id:'infinite', name:'Unendlich',  desc:'Du kannst gar nicht sterben, auch nicht durch dich selbst. Beenden über Zurück.', wrap:true, immortal:true, start:140, min:105, dec:1 },
      { id:'turbo',    name:'Turbo',      desc:'Startet schnell und wird mit jedem Apfel noch schneller.', start:95, min:45, dec:4 },
      { id:'rocks',    name:'Felsen',     desc:'Alle drei Äpfel taucht ein neuer Felsen auf. Nicht dagegen fahren!', rocks:true, start:150, min:80, dec:3 },
      { id:'time',     name:'Zeitrennen', desc:'60 Sekunden, ohne Wände. Sammle so viele Äpfel wie möglich.', wrap:true, time:60, start:120, min:70, dec:2 }
    ];
    const COL_LIGHT = {
      tileA:'#d4eac3', tileB:'#c7e2b3', head:[18,122,95], tail:[138,217,173], headHex:'#127a5f',
      spot:'rgba(255,255,255,.3)', eye:'#ffffff', pupil:'#14241d',
      apple:'#e0383b', appleDark:'#a01d26', leaf:'#3f9b3a', stem:'#6b4226',
      rock:'#9aa3aa', rockDark:'#6f7880', rockLight:'#c9d0d5'
    };
    const COL_DARK = Object.assign({}, COL_LIGHT, {
      tileA:'#1f3a2d', tileB:'#1b3328', head:[63,211,154], tail:[31,122,92], headHex:'#3fd39a',
      spot:'rgba(255,255,255,.14)', rock:'#6f7880', rockDark:'#4d555c', rockLight:'#9aa3aa'
    });
    let COL = COL_LIGHT;
    const canvas = $('canvas'), ctx = canvas.getContext('2d');
    const dTitle = $('dTitle'), dText = $('dText'), dPrimary = $('dPrimary');
    let mode = MODES[0];
    let snake, prev, dir, queue, food, rocks, score, speed, lastTick = 0, crashed = false, foodBorn = 0, timeLeft = 0, shownSec = -1;
    let particles = [];
    let state = 'idle'; // idle | menu | running | paused | over
    let bests = storeGet('snake-bests', {});

    const modeList = makeList($('modeList'),
      MODES.map(m => ({ label: () => m.name, extra: () => bests[m.id] ? '★ ' + bests[m.id] : '' })),
      i => startMode(i), i => { $('modeDesc').textContent = MODES[i].desc; });

    const bestOf = m => bests[m.id] || 0;
    function recordScore(){
      if (score > bestOf(mode)){ bests[mode.id] = score; storeSet('snake-bests', bests); return true; }
      return false;
    }

    function reset(){
      const m = Math.floor(N/2);
      snake = [{x:m-2,y:m},{x:m-3,y:m},{x:m-4,y:m}];
      prev = snake.map(p => ({...p}));
      dir = {x:1,y:0}; queue = []; rocks = []; particles = [];
      score = 0; speed = mode.start; crashed = false;
      timeLeft = mode.time ? mode.time * 1000 : 0; shownSec = -1;
      placeFood(); hud();
    }
    const occupied = (x,y) => snake.some(s => s.x===x && s.y===y) || rocks.some(r => r.x===x && r.y===y);
    function placeFood(){
      const free = [];
      for (let y=0; y<N; y++) for (let x=0; x<N; x++) if (!occupied(x,y)) free.push({x,y});
      food = free.length ? free[Math.floor(Math.random()*free.length)] : null;
      foodBorn = performance.now();
    }
    function addRock(){
      const h = snake[0], free = [];
      for (let y=1; y<N-1; y++) for (let x=1; x<N-1; x++){
        if (occupied(x,y) || (food && food.x===x && food.y===y)) continue;
        if (Math.abs(x-h.x) + Math.abs(y-h.y) < 4) continue;
        let ahead = false;
        for (let k=1; k<=5; k++) if (h.x + dir.x*k === x && h.y + dir.y*k === y) ahead = true;
        if (!ahead) free.push({x,y});
      }
      if (free.length) rocks.push(free[Math.floor(Math.random()*free.length)]);
    }
    function hud(){
      if (state === 'menu'){ setHud('Snake', []); return; }
      const parts = [];
      if (mode.time){ const s = Math.ceil(timeLeft/1000); parts.push(Math.floor(s/60) + ':' + String(s%60).padStart(2,'0')); }
      parts.push('Äpfel ' + score);
      parts.push('Rekord ' + bestOf(mode));
      setHud(mode.name, parts);
    }

    function openMenu(){
      if ((state === 'running' || state === 'paused') && mode.immortal) recordScore();
      enter('snake');
      state = 'menu';
      mode = MODES[modeList.index];
      reset();
      modeList.build();
      only('snakeMenu');
      hud();
      modeList.render(true);
    }
    function showDialog(title, text, primaryLabel){
      dTitle.textContent = title; dText.textContent = text; dPrimary.textContent = primaryLabel;
      only('dialog');
      focusLater(dPrimary);
    }
    function startMode(i){
      if (i !== undefined) modeList.index = i;
      mode = MODES[modeList.index];
      reset(); run();
    }
    function run(){
      state = 'running';
      only();
      blurActive();
      lastTick = performance.now();
      hud();
    }
    function pause(){
      if (state !== 'running') return;
      state = 'paused';
      showDialog('Pause', mode.immortal ? 'Mit Modi oder Zurück beendest du die Runde und speicherst deinen Rekord.' : 'Kurz durchatmen. Die Äpfel laufen nicht weg.', 'Weiter');
    }
    function restart(){ reset(); run(); }
    function gameOver(title, text){
      state = 'over'; crashed = true;
      const rec = recordScore(); hud();
      const n = score === 1 ? '1 Apfel' : score + ' Äpfel';
      showDialog(title, text || (n + ' gesammelt.' + (rec && score > 0 ? ' Neuer Rekord!' : '')), 'Nochmal');
    }
    function leave(){
      if ((state === 'running' || state === 'paused') && mode.immortal) recordScore();
      state = 'idle';
    }

    function step(){
      if (queue.length) dir = queue.shift();
      const h = snake[0];
      let nx = h.x + dir.x, ny = h.y + dir.y;
      const snap = () => { prev = snake.map(p => ({...p})); };
      if (mode.wrap){ nx = (nx + N) % N; ny = (ny + N) % N; }
      else if (nx < 0 || ny < 0 || nx >= N || ny >= N){ snap(); return gameOver('Autsch!'); }
      if (rocks.some(r => r.x===nx && r.y===ny)){ snap(); return gameOver('Bonk!'); }
      const eating = food && nx === food.x && ny === food.y;
      if (!mode.immortal){
        const body = eating ? snake : snake.slice(0, -1);
        if (body.some(s => s.x===nx && s.y===ny)){ snap(); return gameOver('Autsch!'); }
      }
      snap();
      snake.unshift({x:nx, y:ny});
      if (eating){
        score++;
        speed = Math.max(mode.min, speed - mode.dec);
        burst(food.x, food.y);
        if (mode.rocks && score % 3 === 0) addRock();
        placeFood(); hud();
        if (!food) return gameOver('Unglaublich', 'Das ganze Feld ist voll.');
      } else snake.pop();
    }
    function burst(x, y){
      if (reduceMotion) return;
      for (let i=0; i<10; i++){
        const a = Math.random()*Math.PI*2, s = 0.02 + Math.random()*0.04;
        particles.push({ x:x+0.5, y:y+0.5, vx:Math.cos(a)*s, vy:Math.sin(a)*s, life:1, leaf:i<3 });
      }
    }

    /* input */
    function dirPress(name){
      if (state === 'menu'){ if (name === 'up') modeList.move(-1); if (name === 'down') modeList.move(1); return; }
      if (state === 'paused') run();
      if (state !== 'running') return;
      const d = DIRS[name];
      const last = queue.length ? queue[queue.length-1] : dir;
      if ((last.x === d.x && last.y === d.y) || (last.x === -d.x && last.y === -d.y)) return;
      if (queue.length < 3) queue.push(d);
      const now = performance.now();
      if (queue.length === 1 && now - lastTick > speed * 0.3){ lastTick = now; step(); }
    }
    function a(){
      if (state === 'menu') startMode();
      else if (state === 'running') pause();
      else if (state === 'paused') run();
      else if (state === 'over') restart();
    }
    function b(){
      if (state === 'menu') goHome();
      else if (state === 'running') pause();
      else openMenu();
    }
    function pauseKey(){
      if (state === 'running') pause();
      else if (state === 'paused') run();
      else if (state === 'over') restart();
      else if (state === 'menu') startMode();
    }

    /* drawing */
    const mix = (a,b,t) => 'rgb(' + a.map((v,i) => Math.round(v + (b[i]-v)*t)).join(',') + ')';
    function drawBoard(c){
      for (let y=0; y<N; y++) for (let x=0; x<N; x++){ ctx.fillStyle = (x+y)%2 ? COL.tileB : COL.tileA; ctx.fillRect(x*c, y*c, c+1, c+1); }
    }
    function drawRock(r, c){
      const cx = (r.x+0.5)*c, cy = (r.y+0.5)*c, s = c*0.42;
      ctx.fillStyle = 'rgba(0,0,0,.14)'; ctx.beginPath(); ctx.ellipse(cx, cy+s*0.75, s*0.9, s*0.25, 0, 0, Math.PI*2); ctx.fill();
      ctx.fillStyle = COL.rockDark; ctx.beginPath();
      ctx.moveTo(cx-s*0.95, cy+s*0.55); ctx.lineTo(cx-s*0.7, cy-s*0.35); ctx.lineTo(cx-s*0.1, cy-s*0.8);
      ctx.lineTo(cx+s*0.6, cy-s*0.55); ctx.lineTo(cx+s*0.95, cy+s*0.1); ctx.lineTo(cx+s*0.75, cy+s*0.6); ctx.closePath(); ctx.fill();
      ctx.fillStyle = COL.rock; ctx.beginPath();
      ctx.moveTo(cx-s*0.75, cy+s*0.35); ctx.lineTo(cx-s*0.55, cy-s*0.3); ctx.lineTo(cx-s*0.05, cy-s*0.65);
      ctx.lineTo(cx+s*0.5, cy-s*0.42); ctx.lineTo(cx+s*0.7, cy+s*0.05); ctx.lineTo(cx+s*0.2, cy+s*0.4); ctx.closePath(); ctx.fill();
      ctx.fillStyle = COL.rockLight; ctx.beginPath(); ctx.ellipse(cx-s*0.25, cy-s*0.3, s*0.22, s*0.1, -0.5, 0, Math.PI*2); ctx.fill();
    }
    function drawApple(cx, cy, size, now){
      let s = size;
      if (!reduceMotion){
        const age = (now - foodBorn)/260, pop = age < 1 ? 0.6 + 0.4*Math.sin(age*Math.PI/2) : 1;
        s = size * pop * (1 + 0.04*Math.sin(now/280));
      }
      const r = s*0.36;
      ctx.save(); ctx.translate(cx, cy + s*0.04);
      ctx.fillStyle = 'rgba(0,0,0,.14)'; ctx.beginPath(); ctx.ellipse(0, r*1.02, r*0.85, r*0.22, 0, 0, Math.PI*2); ctx.fill();
      const g = ctx.createRadialGradient(-r*0.35, -r*0.35, r*0.1, 0, 0, r*1.25);
      g.addColorStop(0, COL.apple); g.addColorStop(1, COL.appleDark);
      ctx.fillStyle = g; ctx.beginPath();
      ctx.ellipse(-r*0.32, 0.05*r, r*0.72, r*0.86, 0, 0, Math.PI*2);
      ctx.ellipse( r*0.32, 0.05*r, r*0.72, r*0.86, 0, 0, Math.PI*2); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,.4)'; ctx.beginPath(); ctx.ellipse(-r*0.45, -r*0.3, r*0.16, r*0.28, -0.4, 0, Math.PI*2); ctx.fill();
      ctx.strokeStyle = COL.stem; ctx.lineWidth = Math.max(1.5, r*0.16); ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(0, -r*0.62); ctx.quadraticCurveTo(r*0.05, -r*1.0, r*0.22, -r*1.15); ctx.stroke();
      ctx.fillStyle = COL.leaf; ctx.beginPath();
      ctx.moveTo(r*0.12, -r*0.92); ctx.quadraticCurveTo(r*0.55, -r*1.45, r*0.95, -r*1.05); ctx.quadraticCurveTo(r*0.5, -r*0.7, r*0.12, -r*0.92); ctx.fill();
      ctx.restore();
    }
    function drawSnake(c, t){
      const L = snake.length, pts = [];
      for (let i=0; i<L; i++){
        const cur = snake[i], p = prev[i] || cur;
        let dx = cur.x - p.x, dy = cur.y - p.y;
        if (dx > 1) dx -= N; if (dx < -1) dx += N; if (dy > 1) dy -= N; if (dy < -1) dy += N;
        pts.push({ x:(p.x + dx*t + 0.5)*c, y:(p.y + dy*t + 0.5)*c });
      }
      const near = (a,b) => Math.hypot(a.x-b.x, a.y-b.y) < c*1.5;
      ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      ctx.strokeStyle = 'rgba(0,0,0,.12)'; ctx.lineWidth = c*0.74;
      ctx.beginPath(); ctx.moveTo(pts[L-1].x, pts[L-1].y + c*0.08);
      for (let i=L-2; i>=0; i--){ if (near(pts[i], pts[i+1])) ctx.lineTo(pts[i].x, pts[i].y + c*0.08); else ctx.moveTo(pts[i].x, pts[i].y + c*0.08); }
      ctx.stroke();
      for (let i=L-1; i>0; i--){
        const f = i / Math.max(1, L-1);
        ctx.strokeStyle = mix(COL.head, COL.tail, f); ctx.lineWidth = c*(0.74 - 0.26*f);
        ctx.beginPath(); ctx.moveTo(pts[i].x, pts[i].y);
        if (near(pts[i], pts[i-1])) ctx.lineTo(pts[i-1].x, pts[i-1].y); else ctx.lineTo(pts[i].x + 0.01, pts[i].y);
        ctx.stroke();
      }
      ctx.fillStyle = COL.spot;
      for (let i=2; i<L; i+=2){ const f = i/Math.max(1,L-1); ctx.beginPath(); ctx.arc(pts[i].x, pts[i].y, c*(0.12 - 0.05*f), 0, Math.PI*2); ctx.fill(); }
      const h = pts[0];
      let vx = dir.x, vy = dir.y;
      if (L > 1 && near(pts[0], pts[1])){ const dx = pts[0].x-pts[1].x, dy = pts[0].y-pts[1].y, m = Math.hypot(dx,dy); if (m > 0.5){ vx = dx/m; vy = dy/m; } }
      const hr = c*0.43, now = performance.now();
      if (!crashed && !reduceMotion && state === 'running' && (now % 1600) < 260){
        ctx.strokeStyle = '#c8382e'; ctx.lineWidth = Math.max(1.2, c*0.05); ctx.lineCap = 'round';
        const tx = h.x + vx*hr*1.55, ty = h.y + vy*hr*1.55;
        ctx.beginPath(); ctx.moveTo(h.x + vx*hr*0.8, h.y + vy*hr*0.8); ctx.lineTo(tx, ty);
        ctx.moveTo(tx, ty); ctx.lineTo(tx + (vx - vy*0.6)*c*0.12, ty + (vy + vx*0.6)*c*0.12);
        ctx.moveTo(tx, ty); ctx.lineTo(tx + (vx + vy*0.6)*c*0.12, ty + (vy - vx*0.6)*c*0.12);
        ctx.stroke();
      }
      ctx.fillStyle = COL.headHex; ctx.beginPath(); ctx.arc(h.x, h.y, hr, 0, Math.PI*2); ctx.fill();
      const px = -vy, py = vx, eo = hr*0.48, ef = hr*0.25, er = hr*0.3;
      [-1, 1].forEach(side => {
        const ex = h.x + px*eo*side + vx*ef, ey = h.y + py*eo*side + vy*ef;
        if (crashed){
          ctx.strokeStyle = COL.eye; ctx.lineWidth = Math.max(1.5, c*0.06); ctx.lineCap = 'round';
          const k = er*0.7;
          ctx.beginPath(); ctx.moveTo(ex-k, ey-k); ctx.lineTo(ex+k, ey+k); ctx.moveTo(ex+k, ey-k); ctx.lineTo(ex-k, ey+k); ctx.stroke();
        } else {
          ctx.fillStyle = COL.eye; ctx.beginPath(); ctx.arc(ex, ey, er, 0, Math.PI*2); ctx.fill();
          ctx.fillStyle = COL.pupil; ctx.beginPath(); ctx.arc(ex + vx*er*0.35, ey + vy*er*0.35, er*0.55, 0, Math.PI*2); ctx.fill();
          ctx.fillStyle = COL.eye; ctx.beginPath(); ctx.arc(ex + vx*er*0.35 - er*0.18, ey + vy*er*0.35 - er*0.18, er*0.18, 0, Math.PI*2); ctx.fill();
        }
      });
    }
    function drawParticles(c){
      particles.forEach(p => { ctx.globalAlpha = Math.max(0, p.life); ctx.fillStyle = p.leaf ? COL.leaf : COL.apple; ctx.beginPath(); ctx.arc(p.x*c, p.y*c, c*0.08*p.life + 1, 0, Math.PI*2); ctx.fill(); });
      ctx.globalAlpha = 1;
    }

    function update(now, dt){
      if (state === 'idle') return;
      if (state === 'running'){
        if (mode.time){
          timeLeft -= dt;
          const s = Math.ceil(Math.max(0, timeLeft)/1000);
          if (s !== shownSec){ shownSec = s; hud(); }
          if (timeLeft <= 0){
            timeLeft = 0; state = 'over';
            const rec = recordScore(); hud();
            const n = score === 1 ? '1 Apfel' : score + ' Äpfel';
            showDialog('Zeit um!', n + ' in 60 Sekunden.' + (rec && score > 0 ? ' Neuer Rekord!' : ''), 'Nochmal');
          }
        }
        let guard = 0;
        while (state === 'running' && now - lastTick >= speed && guard < 3){ lastTick += speed; step(); guard++; }
        if (guard >= 3) lastTick = now;
      }
      particles.forEach(p => { p.x += p.vx; p.y += p.vy; p.vy += 0.002; p.life -= 0.035; });
      particles = particles.filter(p => p.life > 0);
      COL = isDark() ? COL_DARK : COL_LIGHT;
      const c = canvas.width / N;
      const t = (state === 'running' && !reduceMotion) ? Math.min(1, (now - lastTick)/speed) : 1;
      drawBoard(c);
      rocks.forEach(r => drawRock(r, c));
      if (food) drawApple((food.x+0.5)*c, (food.y+0.5)*c, c, now);
      drawSnake(c, t);
      drawParticles(c);
    }
    function resize(){ resizeCanvas(); }

    $('dPrimary').addEventListener('click', () => { state === 'paused' ? run() : restart(); });
    $('dMenu').addEventListener('click', openMenu);

    return { openMenu, leave, dirPress, a, b, pauseKey, update, resize,
             isRunning: () => state === 'running', pause };
  })();

  /* =================== ROCK PAPER SCISSORS =================== */
  const RPS = (function(){
    const HANDS = [
      { name:'Schere', icon:'h-scissors' },
      { name:'Stein',  icon:'h-rock' },
      { name:'Papier', icon:'h-paper' }
    ];
    const VERBS = { '0-2':'Schere schneidet Papier', '1-0':'Stein schleift Schere', '2-1':'Papier wickelt Stein ein' };
    const TARGETS = [1, 3, 5];
    let opp = 'bot', targetIdx = 1, s1 = 0, s2 = 0, c1 = null, c2 = null, sel = 1, phase = 'idle', timers = [], round = 0;
    let stats = storeGet('rps-stats', { wins:0, losses:0 });

    let setupStep = 'opp';
    const OPP_ITEMS = [
      { label: () => 'Gegen den Bot', extra: () => stats.wins + stats.losses ? stats.wins + ':' + stats.losses : '' },
      { label: () => '2 Spieler' }
    ];
    const LEN_ITEMS = [
      { label: () => 'Bis 1 Sieg',  extra: () => 'kurz' },
      { label: () => 'Bis 3 Siege', extra: () => 'normal' },
      { label: () => 'Bis 5 Siege', extra: () => 'lang' }
    ];
    const OPP_DESC = [
      'Du gegen den Bot. Er wählt zufällig, ganz ehrlich.',
      'Zu zweit an einem Gerät. Ihr wählt nacheinander, der andere schaut weg.'
    ];
    const LEN_DESC = [
      'Eine einzige Runde entscheidet alles.',
      'Wer zuerst drei Runden gewinnt, holt das Match.',
      'Für lange Duelle: zuerst fünf Siege.'
    ];
    const setupList = makeList($('rpsList'), OPP_ITEMS, i => {
      if (setupStep === 'opp'){ opp = i === 0 ? 'bot' : 'p2'; showLen(); }
      else { targetIdx = i; newMatch(); }
    }, i => { $('rpsDesc').textContent = (setupStep === 'opp' ? OPP_DESC : LEN_DESC)[i] || ''; });

    function showOpp(){
      setupStep = 'opp'; setupList.items = OPP_ITEMS; setupList.index = opp === 'bot' ? 0 : 1;
      $('rpsTitle').textContent = 'Schere Stein Papier';
      setupList.build(); setupList.render(true);
    }
    function showLen(){
      setupStep = 'len'; setupList.items = LEN_ITEMS; setupList.index = targetIdx;
      $('rpsTitle').textContent = 'Wie viele Siege?';
      setupList.build(); setupList.render(true);
    }
    const nameL = () => opp === 'bot' ? 'Du' : 'Spieler 1';
    const nameR = () => opp === 'bot' ? 'Bot' : 'Spieler 2';
    function hud(){
      if (phase === 'setup') return setHud('Schere Stein Papier', []);
      setHud('Bis ' + TARGETS[targetIdx], [nameL() + ' ' + s1 + ' : ' + s2 + ' ' + nameR()]);
    }
    function clearTimers(){ timers.forEach(clearTimeout); timers = []; }

    function openSetup(){
      clearTimers();
      enter('rps'); phase = 'setup';
      only('rpsSetup'); hud();
      showOpp();
    }
    function leave(){ clearTimers(); phase = 'idle'; }
    function newMatch(){ s1 = 0; s2 = 0; round = 0; nextRound(); }
    function nextRound(){
      clearTimers();
      c1 = null; c2 = null; round++;
      choose(1);
    }

    function buildChoices(){
      const wrap = $('choices'); wrap.innerHTML = '';
      HANDS.forEach((h, i) => {
        const b = document.createElement('button');
        b.type = 'button'; b.className = 'tile' + (i === sel ? ' sel' : '');
        b.innerHTML = '<svg viewBox="0 0 100 80" aria-hidden="true"><use href="#' + h.icon + '"/></svg><span></span>';
        b.querySelector('span').textContent = (i+1) + ' ' + h.name;
        b.addEventListener('click', () => pick(i));
        b.addEventListener('mouseenter', () => { sel = i; renderSel(false); });
        b.addEventListener('focus', () => { sel = i; renderSel(false); });
        wrap.appendChild(b);
      });
    }
    function renderSel(focus){
      [...$('choices').children].forEach((b, i) => b.classList.toggle('sel', i === sel));
      if (focus) $('choices').children[sel].focus({preventScroll:true});
    }
    function choose(player){
      phase = player === 1 ? 'choose1' : 'choose2';
      sel = 1;
      if (opp === 'bot'){ $('chooseTitle').textContent = 'Runde ' + round; $('chooseSub').textContent = 'Was nimmst du?'; }
      else if (player === 1){ $('chooseTitle').textContent = 'Spieler 1 ist dran'; $('chooseSub').textContent = 'Spieler 2 schaut weg.'; }
      else { $('chooseTitle').textContent = 'Spieler 2 ist dran'; $('chooseSub').textContent = 'Spieler 1 schaut weg.'; }
      buildChoices();
      only('rpsChoose'); hud();
      renderSel(true);
    }
    function pick(i){
      if (phase === 'choose1'){
        c1 = i;
        if (opp === 'bot'){ c2 = Math.floor(Math.random()*3); reveal(); }
        else { phase = 'handoff'; only('rpsHandoff'); focusLater($('handoffBtn')); }
      } else if (phase === 'choose2'){
        c2 = i; reveal();
      }
    }
    function setHand(svg, hand, anim){
      svg.querySelector('use').setAttribute('href', '#' + HANDS[hand].icon);
      svg.setAttribute('aria-label', HANDS[hand].name);
      svg.classList.remove('pump', 'pop');
      void svg.getBoundingClientRect();
      if (anim && !reduceMotion) svg.classList.add(anim);
    }
    function reveal(){
      phase = 'count';
      blurActive();
      $('nameL').textContent = nameL(); $('nameR').textContent = nameR();
      $('sideL').classList.remove('win'); $('sideR').classList.remove('win');
      setHand($('handL'), 1, 'pump'); setHand($('handR'), 1, 'pump');
      $('handL').setAttribute('aria-label', 'Faust'); $('handR').setAttribute('aria-label', 'Faust');
      $('resultText').textContent = ''; $('arenaRow').hidden = true;
      only('rpsArena');
      const words = ['Schere…', 'Stein…', 'Papier!'];
      const stepMs = reduceMotion ? 150 : 420;
      words.forEach((w, k) => timers.push(setTimeout(() => { $('callout').textContent = w; }, k*stepMs)));
      timers.push(setTimeout(showResult, words.length*stepMs));
    }
    function showResult(){
      setHand($('handL'), c1, 'pop'); setHand($('handR'), c2, 'pop');
      const diff = (c1 - c2 + 3) % 3;
      let text;
      if (diff === 0){ $('callout').textContent = 'Unentschieden'; text = 'Beide haben ' + HANDS[c1].name + '.'; }
      else {
        const leftWins = diff === 1;
        const w = leftWins ? c1 : c2, l = leftWins ? c2 : c1;
        if (leftWins){ s1++; $('sideL').classList.add('win'); } else { s2++; $('sideR').classList.add('win'); }
        const winner = leftWins ? nameL() : nameR();
        $('callout').textContent = (opp === 'bot' ? (leftWins ? 'Punkt für dich!' : 'Punkt für den Bot') : 'Punkt für ' + winner);
        text = VERBS[w + '-' + l] + '.';
      }
      $('resultText').textContent = text;
      hud();
      const done = s1 >= TARGETS[targetIdx] || s2 >= TARGETS[targetIdx];
      $('nextBtn').textContent = done ? 'Ergebnis' : 'Nächste Runde';
      $('arenaRow').hidden = false;
      phase = 'result';
      focusLater($('nextBtn'));
    }
    function afterResult(){
      if (s1 >= TARGETS[targetIdx] || s2 >= TARGETS[targetIdx]) matchOver();
      else nextRound();
    }
    function matchOver(){
      phase = 'match';
      const leftWon = s1 > s2;
      if (opp === 'bot'){
        if (leftWon) stats.wins++; else stats.losses++;
        storeSet('rps-stats', stats);
        $('matchTitle').textContent = leftWon ? 'Du hast gewonnen!' : 'Der Bot gewinnt';
        $('matchSub').textContent = 'Gesamtbilanz gegen den Bot: ' + stats.wins + ' Siege, ' + stats.losses + ' Niederlagen.';
      } else {
        $('matchTitle').textContent = (leftWon ? 'Spieler 1' : 'Spieler 2') + ' gewinnt!';
        $('matchSub').textContent = 'Revanche?';
      }
      $('matchScore').textContent = s1 + ' : ' + s2;
      only('rpsMatch'); hud();
      focusLater($('againBtn'));
    }

    $('handoffBtn').addEventListener('click', () => choose(2));
    $('nextBtn').addEventListener('click', afterResult);
    $('againBtn').addEventListener('click', newMatch);
    $('rpsMenuBtn').addEventListener('click', openSetup);

    function dirPress(name){
      if (phase === 'setup'){
        if (name === 'up') setupList.move(-1);
        if (name === 'down') setupList.move(1);
        return;
      }
      if (phase === 'choose1' || phase === 'choose2'){
        if (name === 'left') { sel = (sel + 2) % 3; renderSel(true); }
        if (name === 'right'){ sel = (sel + 1) % 3; renderSel(true); }
      }
    }
    function a(){
      if (phase === 'setup'){ const btn = $('rpsList').querySelectorAll('button')[setupList.index]; if (btn) btn.click(); }
      else if (phase === 'choose1' || phase === 'choose2') pick(sel);
      else if (phase === 'handoff') choose(2);
      else if (phase === 'result') afterResult();
      else if (phase === 'match') newMatch();
    }
    function b(){
      if (phase === 'setup'){ setupStep === 'len' ? showOpp() : goHome(); }
      else if (phase !== 'count') openSetup();
    }
    function digit(n){ if (phase === 'choose1' || phase === 'choose2'){ sel = n; renderSel(false); pick(n); } }

    return { openSetup, leave, dirPress, a, b, digit };
  })();

  /* =================== FROSCHSPRUNG =================== */
  const Frog = (function(){
    let VW = 12; const H = 12, STEP = 1/120;
    const G = 40, JUMP = 15.6, MAXV = 6.2, FALL = 18, SPRING = 21.5;
    const canvas = $('canvas'), ctx = canvas.getContext('2d');
    const dark = document.createElement('canvas'), dctx = dark.getContext('2d');
    const BASE = {
      ink:'#1f2a24', frog:'#5fb041', frogDark:'#3a7d2a', belly:'#e6f3bb', eye:'#ffffff',
      apple:'#e0383b', appleDark:'#a01d26', leaf:'#3f9b3a', stem:'#6b4226', beetle:'#4a3a78', shine:'#8f7dc4',
      spike:'#8a95a0', water:'#4aa3c7', waterLight:'#a6dcef', pad:'#4f9a3a', flower:'#f08cb0', lampOff:'#8d927f', lampOn:'#ffcf4a',
      wood:'#c79c5e', woodDark:'#8e6c3e', ice:'#a8dcea', iceLight:'#eefafd', iceDark:'#74b6cc',
      clover:'#2f9e5a', cloverLight:'#e6f8cc', crumble:'#bba57d', crumbleDark:'#7e6b4c', spring:'#ec5b3c', heart:'#e2496a'
    };
    const THEMES = {
      meadow:{ sky:'#bfe4f5', hill:'#a8d98e', hill2:'#8fca77', dirt:'#8a5a3a', dirtDot:'#a06c46', grass:'#5bb84f', grassLight:'#88d67b' },
      swamp: { sky:'#cfe4da', hill:'#96c2a3', hill2:'#7dae8b', dirt:'#5e4b38', dirtDot:'#735d46', grass:'#6f9d4a', grassLight:'#93c066' },
      trees: { sky:'#cdeaf6', hill:'#72b85e', hill2:'#5aa249', dirt:'#7d5434', dirtDot:'#95653f', grass:'#3f9b3a', grassLight:'#65c257' },
      ice:   { sky:'#e0f1f9', hill:'#c0deec', hill2:'#a9cfe2', dirt:'#5a6f7d', dirtDot:'#6f8594', grass:'#d8eef7', grassLight:'#ffffff' },
      night: { sky:'#1d2b45', hill:'#233756', hill2:'#1b2c47', dirt:'#2d2b37', dirtDot:'#3b3946', grass:'#2f6b45', grassLight:'#41905d', dark:true }
    };
    let C = Object.assign({}, BASE, THEMES.meadow);
    const SOLID = { '#':1, '=':1, 'I':1, 'C':1, 'S':1, 'L':1, 'U':1 };

    const LEVELS = [
      { name:'Wiese', theme:'meadow', w:101, desc:'Sanfter Einstieg über grüne Hügel. Spring Kleeblöcke von unten an!', build(L){
        L.ground(0,18,2); L.apples(6,8,3); L.lucky(7,7); L.beetle(14);
        L.ground(21,34,2); L.block(26,8,3,1); L.apples(26,7,3); L.beetle(31);
        L.ground(35,44,3); L.beetle(41);
        L.ground(48,75,2); L.lantern(49); L.spikes(53,54); L.block(57,8,2,1); L.block(60,6,2,1); L.apples(60,5,2);
        L.lucky(64,7); L.beetle(66); L.beetle(71); L.apples(68,8,3);
        L.ground(76,77,3); L.ground(78,79,4); L.ground(80,81,5); L.apples(83,5,2);
        L.ground(85,100,2); L.apples(88,9,3); L.beetle(91); L.goal(95);
      }},
      { name:'Sumpf', theme:'swamp', w:98, desc:'Wackelige Sprünge über dem Sumpf. Mehr Käfer, mehr Stacheln.', build(L){
        L.ground(0,10,2); L.apples(5,9,2);
        L.block(13,8,2,1); L.block(17,7,2,1); L.block(21,8,2,1); L.apples(17,6,2);
        L.ground(23,35,2); L.lantern(24); L.lucky(26,7); L.beetle(28); L.spikes(30,30); L.beetle(33);
        L.ground(36,48,4); L.block(42,6,3,1); L.apples(42,5,3); L.beetle(46);
        L.ground(51,62,2); L.spikes(57,58); L.apples(57,7,2); L.beetle(60);
        L.ground(63,64,2);
        L.block(66,8,2,1); L.block(70,6,2,1); L.block(74,8,2,1); L.apples(70,5,2);
        L.ground(77,97,2); L.lantern(79); L.lucky(81,7); L.beetle(83); L.block(85,8,4,1); L.apples(85,7,4); L.beetle(88); L.spikes(90,90);
        L.goal(93);
      }},
      { name:'Baumkronen', theme:'trees', w:110, desc:'Neu: bewegliche Plattformen, Sprungfedern und Fliegen.', build(L){
        L.ground(0,8,5); L.apples(2,6,3); L.lucky(6,4);
        L.platform(10,7,2.5,'x',5,1.2);
        L.ground(19,23,5); L.beetle(21);
        L.ground(25,29,2); L.spring(27); L.apples(25,9,2);
        L.ground(30,36,8); L.apples(31,3,3); L.fly(34,2,1.2,0.4);
        L.platform(38,4,2.5,'x',4,1.0);
        L.ground(45,50,6); L.lantern(46); L.lucky(48,3);
        L.platform(53,5,2,'y',4,1.1); L.platform(57,5,2,'y',4,1.1,Math.PI); L.platform(61,7,2,'x',2,1.4);
        L.ground(65,75,4); L.apples(66,7,2); L.beetle(69); L.spring(74);
        L.ground(77,82,9); L.apples(78,2,3);
        L.platform(84,5,2.5,'x',5,1.0);
        L.ground(92,109,4); L.fly(97,5,1.5,0.5); L.lucky(100,5); L.goal(103);
      }},
      { name:'Eishöhle', theme:'ice', w:105, desc:'Neu: rutschiges Eis, bröckelnde Plattformen und fallende Eiszapfen.', build(L){
        L.ceiling(0,104,2);
        L.ice(0,14,2); L.apples(5,9,3); L.icicle(9); L.beetle(12);
        L.crumble(16,9,2); L.crumble(20,8,2);
        L.ice(23,34,2); L.lantern(24); L.icicle(27); L.icicle(30); L.lucky(32,7);
        L.ice(35,44,3); L.spikes(39,40); L.beetle(43);
        L.crumble(46,8,2); L.crumble(50,7,2); L.crumble(54,8,2);
        L.ice(57,70,2); L.icicle(60); L.icicle(62); L.icicle(64); L.apples(60,9,5); L.fly(67,6,1.5,0.5);
        L.ground(71,80,2); L.lantern(72); L.lucky(76,7);
        L.ice(81,104,2); L.spikes(86,87); L.icicle(91); L.beetle(95); L.goal(98);
      }},
      { name:'Nachtwald', theme:'night', w:116, desc:'Neu: Dunkelheit! Laternen und Glühwürmchen spenden Licht.', build(L){
        L.ground(0,12,2); L.apples(4,9,3); L.fly(10,6,1.2,0.5);
        L.platform(14,9,2.5,'x',5,1.1);
        L.ground(22,33,2); L.lantern(23); L.beetle(27); L.spring(32);
        L.ground(35,40,7); L.apples(36,4,2); L.lucky(38,2);
        L.crumble(42,6,2); L.crumble(46,7,2); L.crumble(50,8,2);
        L.ground(53,64,2); L.spikes(56,57); L.fly(60,6,1.5,0.5);
        L.platform(66,6,2,'y',3,1.0); L.platform(70,8,2,'x',3,1.2);
        L.ground(76,90,2); L.lantern(77); L.beetle(81); L.lucky(83,7); L.beetle(86); L.fly(88,5,1,0.5);
        L.ground(91,93,2); L.spring(92);
        L.ground(95,99,7); L.apples(96,4,3);
        L.ground(100,115,2); L.lantern(101); L.goal(108);
      }}
    ];

    let progress = storeGet('frog-progress', { unlocked:1, best:{} });
    let state = 'idle', levelIdx = 0, L = null, p = null, cam = 0, lives = 3, applesGot = 0, acc = 0, cp = 2, deathT = 0, particles = [];
    let hold = { left:false, right:false }, jumpHeld = false, jumpBuffer = 0, coyote = 0, shield = false, superT = 0, clock = 0;

    const levelList = makeList($('frogList'),
      LEVELS.map((lv, i) => ({
        label: () => (i+1) + ' ' + lv.name,
        extra: () => i < progress.unlocked ? (progress.best[i] !== undefined ? '★ ' + progress.best[i] : '') : 'gesperrt'
      })),
      i => { if (i < progress.unlocked) startLevel(i); },
      i => { $('frogDesc').textContent = i < progress.unlocked ? LEVELS[i].desc : 'Schaff zuerst das Level davor.'; });

    function makeLevel(def){
      const g = Array.from({length:H}, () => Array(def.w).fill(' '));
      const lv = { w:def.w, g, apples:[], beetles:[], flies:[], lanterns:[], platforms:[], icicles:[], popups:[], fireflies:[],
                   bumps:{}, crumbles:{}, springs:{}, goal:def.w - 6 };
      lv.groundTop = x => { let y = H-1; while (y >= 0 && SOLID[g[y][x]]) y--; return y + 1; };
      const ceilBottom = x => { let y = 0; while (y < H && SOLID[g[y][x]]) y++; return y; };
      const B = {
        ground:(a,b,h,ch) => { for (let x=a; x<=b; x++) for (let y=H-h; y<H; y++) g[y][x] = ch || '#'; },
        ice:(a,b,h) => B.ground(a,b,h,'I'),
        ceiling:(a,b,rows) => { for (let x=a; x<=b; x++) for (let y=0; y<rows; y++) g[y][x] = '#'; },
        block:(x,y,bw,bh) => { for (let i=0; i<bw; i++) for (let j=0; j<bh; j++) g[y+j][x+i] = '='; },
        crumble:(x,y,n) => { for (let i=0; i<n; i++) g[y][x+i] = 'C'; },
        spring:x => { const y = lv.groundTop(x); g[y-1][x] = 'S'; },
        lucky:(x,y) => { g[y][x] = 'L'; },
        spikes:(a,b) => { for (let x=a; x<=b; x++){ const y = lv.groundTop(x); if (y > 0 && y < H) g[y-1][x] = '^'; } },
        apples:(x,y,n) => { for (let i=0; i<n; i++) lv.apples.push({ x:x+i+0.5, y:y+0.5, got:false }); },
        beetle:x => lv.beetles.push({ x:x+0.1, y:0, w:0.8, h:0.6, vx:-1.5, alive:true, squash:0, anim:Math.random()*3 }),
        fly:(x,y,ax,ay) => lv.flies.push({ x0:x+0.5, y0:y+0.5, x:x+0.5, y:y+0.5, ax:ax||1.5, ay:ay||0.5, t:Math.random()*6, alive:true, squash:0 }),
        lantern:x => lv.lanterns.push({ x, lit:false }),
        platform:(x,y,w,axis,range,speed,phase) => lv.platforms.push({ x0:x, y0:y, x, y, w, h:0.35, axis, range, speed, phase:phase||0, t:0, dx:0, dy:0 }),
        icicle:x => lv.icicles.push({ x:x+0.5, y:0, state:'hang', t:0, vy:0 }),
        goal:x => { lv.goal = x; }
      };
      def.build(B);
      lv.beetles.forEach(b => { b.y = lv.groundTop(Math.floor(b.x + 0.4)) - b.h; });
      lv.icicles.forEach(ic => { ic.y = ceilBottom(Math.floor(ic.x)); });
      lv.platforms.forEach(pl => placePlatform(pl));
      if (THEMES[def.theme].dark){
        for (let i=0; i<34; i++) lv.fireflies.push({ x:Math.random()*def.w, y:1.5 + Math.random()*7, ph:Math.random()*10 });
      }
      return lv;
    }
    function placePlatform(pl){
      const off = pl.range * (0.5 - 0.5*Math.cos(pl.t*pl.speed + pl.phase));
      const nx = pl.axis === 'x' ? pl.x0 + off : pl.x0, ny = pl.axis === 'y' ? pl.y0 + off : pl.y0;
      pl.dx = nx - pl.x; pl.dy = ny - pl.y; pl.x = nx; pl.y = ny;
    }
    const tile = (x,y) => (x < 0 || x >= L.w) ? '#' : (y < 0 || y >= H) ? ' ' : L.g[y][x];
    const solidAt = (x,y) => !!SOLID[tile(x,y)];

    function hud(){
      if (state === 'start' || !L){ setHud('Froschsprung', []); return; }
      setHud('Level ' + (levelIdx+1), ['Leben ' + Math.max(0, lives), 'Äpfel ' + applesGot]);
    }
    function showDialog(title, text, primary){
      $('fTitle').textContent = title; $('fText').textContent = text; $('fPrimary').textContent = primary;
      only('frogDialog'); focusLater($('fPrimary'));
    }
    function clearHold(){ hold.left = hold.right = false; jumpHeld = false; }
    function popup(x, y, text){ L.popups.push({ x, y, text, t:1.4 }); }

    function openStart(){
      enter('frog'); state = 'start'; clearHold();
      levelList.build();
      levelList.index = Math.min(progress.unlocked - 1, LEVELS.length - 1);
      only('frogStart'); hud();
      levelList.render(true);
    }
    function leave(){ state = 'idle'; clearHold(); }
    function spawn(){
      const tx = Math.floor(cp);
      p = { x:cp + 0.15, y:L.groundTop(tx) - 0.8, w:0.7, h:0.8, vx:0, vy:0, onGround:false, face:1, inv:1.0, anim:0, dead:false, bounce:false, riding:null };
      coyote = 0; jumpBuffer = 0; superT = 0;
    }
    function startLevel(i){
      levelIdx = i; L = makeLevel(LEVELS[i]);
      C = Object.assign({}, BASE, THEMES[LEVELS[i].theme]);
      lives = 3; applesGot = 0; cp = 2; particles = []; shield = false;
      spawn(); cam = 0; acc = 0;
      state = 'running'; only(); blurActive(); hud();
    }
    function pause(){
      if (state !== 'running') return;
      state = 'paused'; clearHold();
      showDialog('Pause', 'Quak macht kurz Rast auf einem Seerosenblatt.', 'Weiter');
    }
    function resume(){ state = 'running'; acc = 0; only(); blurActive(); }

    function die(){
      lives--; hud(); shield = false;
      state = 'dying'; deathT = 0.9; p.dead = true; p.vy = -10; p.vx = 0; p.riding = null;
    }
    function hurt(){
      if (p.inv > 0) return;
      if (shield){
        shield = false; p.inv = 1.2; p.vy = -9; p.bounce = true;
        popup(p.x + p.w/2, p.y - 0.3, 'Blase geplatzt');
        burst(p.x + p.w/2, p.y + p.h/2, ['#eaf6ff', '#bfe0f2']);
      } else die();
    }
    function afterDeath(){
      if (lives <= 0){ state = 'over'; showDialog('Game over', 'Quak hat sich verhüpft. ' + applesGot + ' Äpfel gesammelt.', 'Nochmal'); }
      else { spawn(); state = 'running'; }
    }
    function win(){
      state = 'won'; clearHold();
      const prevBest = progress.best[levelIdx];
      if (prevBest === undefined || applesGot > prevBest) progress.best[levelIdx] = applesGot;
      const last = levelIdx + 1 >= LEVELS.length;
      if (!last) progress.unlocked = Math.max(progress.unlocked, levelIdx + 2);
      storeSet('frog-progress', progress);
      showDialog(last ? 'Quak ist zuhause!' : 'Level geschafft!',
        (last ? 'Alle fünf Level gemeistert. ' : '') + applesGot + (applesGot === 1 ? ' Apfel' : ' Äpfel') + ' gesammelt.',
        last ? 'Nochmal' : 'Nächstes Level');
    }

    function hitLucky(tx, ty){
      L.g[ty][tx] = 'U';
      L.bumps[tx + ',' + ty] = 0.2;
      const cx = tx + 0.5, r = Math.random();
      burst(cx, ty, [C.cloverLight, C.clover]);
      if (r < 0.35){
        [-1, 0, 1].forEach(k => L.apples.push({ x:cx + k*0.9, y:ty + 0.5, sy:ty + 0.5, ty:ty - 1.1 - (k === 0 ? 0.5 : 0), t:0, got:false }));
        popup(cx, ty - 0.6, 'Apfelregen!');
      } else if (r < 0.55){
        lives = Math.min(5, lives + 1); hud();
        popup(cx, ty - 0.6, '+1 Leben');
      } else if (r < 0.75){
        shield = true;
        popup(cx, ty - 0.6, 'Schutzblase!');
      } else if (r < 0.9){
        superT = 10;
        popup(cx, ty - 0.6, 'Sprungkraft!');
      } else {
        L.flies.push({ x0:cx, y0:ty - 1.4, x:cx, y:ty - 1.4, ax:1.0, ay:0.35, t:0, alive:true, squash:0 });
        popup(cx, ty - 0.6, 'Pech! Fliege!');
      }
    }

    function moveX(e, dx){
      e.x += dx;
      const top = Math.floor(e.y), bot = Math.floor(e.y + e.h - 1e-4);
      if (dx > 0){ const tx = Math.floor(e.x + e.w); for (let ty=top; ty<=bot; ty++) if (solidAt(tx,ty)){ e.x = tx - e.w; e.vx = 0; return; } }
      else if (dx < 0){ const tx = Math.floor(e.x); for (let ty=top; ty<=bot; ty++) if (solidAt(tx,ty)){ e.x = tx + 1; e.vx = 0; return; } }
    }
    function moveY(e, dy, isPlayer){
      e.y += dy; e.onGround = false;
      const l = Math.floor(e.x), r = Math.floor(e.x + e.w - 1e-4);
      if (dy > 0){
        const ty = Math.floor(e.y + e.h);
        for (let tx=l; tx<=r; tx++) if (solidAt(tx,ty)){ e.y = ty - e.h; e.vy = 0; e.onGround = true; return; }
      } else if (dy < 0){
        const ty = Math.floor(e.y);
        let hit = false, luckyX = null, best = 9;
        for (let tx=l; tx<=r; tx++) if (solidAt(tx,ty)){
          hit = true;
          if (tile(tx,ty) === 'L'){ const d = Math.abs(tx + 0.5 - (e.x + e.w/2)); if (d < best){ best = d; luckyX = tx; } }
        }
        if (hit){
          e.y = ty + 1; e.vy = 0;
          if (isPlayer && luckyX !== null) hitLucky(luckyX, ty);
        }
      }
    }
    function burst(x, y, colors){
      if (reduceMotion) return;
      for (let i=0; i<9; i++){
        const a = Math.random()*Math.PI*2, s = 2 + Math.random()*3;
        particles.push({ x, y, vx:Math.cos(a)*s, vy:Math.sin(a)*s - 2, life:1, color: colors[i % colors.length] });
      }
    }
    function feetTiles(){
      const y = Math.floor(p.y + p.h + 0.02), l = Math.floor(p.x + 0.05), r = Math.floor(p.x + p.w - 0.05), out = [];
      for (let x=l; x<=r; x++) out.push({ x, y, ch:tile(x,y) });
      return out;
    }
    function overlapsTile(x, y){ return p.x < x + 1 && p.x + p.w > x && p.y < y + 1 && p.y + p.h > y; }

    function tick(dt){
      clock += dt;
      particles.forEach(q => { q.x += q.vx*dt; q.y += q.vy*dt; q.vy += 12*dt; q.life -= dt*2; });
      particles = particles.filter(q => q.life > 0);
      L.popups.forEach(q => { q.t -= dt; q.y -= dt*0.8; });
      L.popups = L.popups.filter(q => q.t > 0);
      for (const k in L.bumps){ L.bumps[k] -= dt; if (L.bumps[k] <= 0) delete L.bumps[k]; }
      for (const k in L.springs){ L.springs[k] -= dt; if (L.springs[k] <= 0) delete L.springs[k]; }
      L.beetles.forEach(b => { if (!b.alive && b.squash > 0) b.squash -= dt; });
      L.flies.forEach(f => { if (!f.alive && f.squash > 0) f.squash -= dt; });
      L.apples.forEach(a => {
        if (a.t !== undefined && a.t < 0.45){ a.t += dt; const k = Math.min(1, a.t/0.45), e = 1 - (1-k)*(1-k); a.y = a.sy + (a.ty - a.sy)*e; }
      });
      for (const k in L.crumbles){
        const cr = L.crumbles[k];
        cr.t -= dt;
        if (cr.state === 'shake' && cr.t <= 0){
          L.g[cr.y][cr.x] = ' '; cr.state = 'gone'; cr.t = 4;
          burst(cr.x + 0.5, cr.y + 0.5, [C.crumble, C.crumbleDark]);
        } else if (cr.state === 'gone' && cr.t <= 0 && !(p && overlapsTile(cr.x, cr.y))){
          L.g[cr.y][cr.x] = 'C'; delete L.crumbles[k];
        }
      }
      L.platforms.forEach(pl => { pl.t += dt; placePlatform(pl); });
      if (superT > 0) superT -= dt;

      if (state === 'dying'){
        deathT -= dt; p.vy += G*0.6*dt; p.y += p.vy*dt;
        if (deathT <= 0) afterDeath();
        return;
      }

      if (p.riding){ moveX(p, p.riding.dx); p.y += p.riding.dy; }

      const feet = feetTiles();
      const onIce = p.onGround && feet.some(f => f.ch === 'I');
      const dir = (hold.right ? 1 : 0) - (hold.left ? 1 : 0);
      const maxv = onIce ? 7.2 : MAXV;
      if (dir){
        if (p.onGround && !onIce && Math.sign(p.vx) === -dir) p.vx += dir*45*dt;
        p.vx += dir*(p.onGround ? (onIce ? 14 : 55) : 35)*dt;
        if (Math.abs(p.vx) > maxv) p.vx = Math.sign(p.vx)*maxv;
        p.face = dir;
      } else {
        const dec = (p.onGround ? (onIce ? 3 : 50) : 12)*dt;
        p.vx = Math.abs(p.vx) <= dec ? 0 : p.vx - Math.sign(p.vx)*dec;
      }
      coyote = p.onGround ? 0.1 : coyote - dt;
      jumpBuffer -= dt;
      if (jumpBuffer > 0 && coyote > 0){
        p.vy = -(superT > 0 ? JUMP*1.22 : JUMP); coyote = 0; jumpBuffer = 0; p.onGround = false; p.riding = null; p.bounce = false;
      }
      const grav = (p.vy < 0 && !jumpHeld && !p.bounce) ? G*2.4 : G;
      p.vy = Math.min(FALL, p.vy + grav*dt);
      const prevBottom = p.y + p.h;
      moveX(p, p.vx*dt);
      moveY(p, p.vy*dt, true);

      p.riding = null;
      if (p.vy >= 0){
        for (const pl of L.platforms){
          if (p.x + p.w > pl.x + 0.05 && p.x < pl.x + pl.w - 0.05 && prevBottom <= pl.y + 0.15 + Math.max(0, pl.dy) && p.y + p.h >= pl.y){
            p.y = pl.y - p.h; p.vy = 0; p.onGround = true; p.riding = pl; break;
          }
        }
      }
      if (p.vy >= 0) p.bounce = false;
      if (p.inv > 0) p.inv -= dt;
      p.anim += Math.abs(p.vx)*dt;

      if (p.onGround && !p.riding){
        const ft = feetTiles();
        const spring = ft.find(f => f.ch === 'S');
        if (spring){
          p.vy = -SPRING; p.bounce = true; p.onGround = false;
          L.springs[spring.x + ',' + spring.y] = 0.25;
        }
        ft.forEach(f => {
          const k = f.x + ',' + f.y;
          if (f.ch === 'C' && !L.crumbles[k]) L.crumbles[k] = { x:f.x, y:f.y, state:'shake', t:0.5 };
        });
      }

      const target = Math.max(0, Math.min(L.w - VW, p.x + p.w/2 - VW*0.42));
      cam += (target - cam) * Math.min(1, dt*8);

      if (p.y > H + 0.5){ die(); return; }
      const x0 = Math.floor(p.x + 0.12), x1 = Math.floor(p.x + p.w - 0.12), yb = p.y + p.h;
      for (let x=x0; x<=x1; x++) for (let y=Math.floor(p.y); y<=Math.floor(yb - 0.01); y++){
        if (tile(x,y) === '^' && yb > y + 0.45){ hurt(); if (state !== 'running') return; }
      }
      L.apples.forEach(a => {
        if (!a.got && (a.t === undefined || a.t > 0.25) && Math.abs(a.x - (p.x + p.w/2)) < 0.6 && Math.abs(a.y - (p.y + p.h/2)) < 0.65){
          a.got = true; applesGot++; burst(a.x, a.y, [C.leaf, C.apple, C.apple]); hud();
        }
      });
      L.lanterns.forEach(l => { if (!l.lit && p.x + p.w/2 >= l.x + 0.5){ l.lit = true; cp = l.x; } });

      const stomp = (top) => p.vy > 0 && (p.y + p.h) - top < 0.5;
      for (const b of L.beetles){
        if (!b.alive) continue;
        b.anim += dt;
        const front = b.vx > 0 ? b.x + b.w + 0.02 : b.x - 0.02;
        const fx = Math.floor(front), by = Math.floor(b.y + b.h - 0.01);
        const groundAhead = solidAt(fx, Math.floor(b.y + b.h + 0.05));
        if (solidAt(fx, by) || tile(fx, by) === '^' || !groundAhead) b.vx = -b.vx;
        else b.x += b.vx*dt;
        if (p.x < b.x + b.w && p.x + p.w > b.x && p.y < b.y + b.h && p.y + p.h > b.y){
          if (stomp(b.y)){
            b.alive = false; b.squash = 0.5; p.vy = jumpHeld ? -JUMP*0.85 : -9; p.bounce = jumpHeld;
            burst(b.x + b.w/2, b.y + b.h/2, [C.ink, C.beetle]);
          } else { hurt(); if (state !== 'running') return; }
        }
      }
      for (const f of L.flies){
        if (!f.alive) continue;
        f.t += dt;
        f.x = f.x0 + Math.sin(f.t*0.9)*f.ax; f.y = f.y0 + Math.sin(f.t*2.2)*f.ay;
        const fl = f.x - 0.3, ft = f.y - 0.25;
        if (p.x < fl + 0.6 && p.x + p.w > fl && p.y < ft + 0.5 && p.y + p.h > ft){
          if (stomp(ft)){
            f.alive = false; f.squash = 0.5; p.vy = jumpHeld ? -JUMP*0.85 : -9; p.bounce = jumpHeld;
            burst(f.x, f.y, [C.ink, '#dfe8f0']);
          } else { hurt(); if (state !== 'running') return; }
        }
      }
      for (const ic of L.icicles){
        if (ic.state === 'hang'){
          if (Math.abs(p.x + p.w/2 - ic.x) < 1.4 && p.y > ic.y){ ic.state = 'shake'; ic.t = 0.4; }
        } else if (ic.state === 'shake'){
          ic.t -= dt; if (ic.t <= 0) ic.state = 'fall';
        } else if (ic.state === 'fall'){
          ic.vy = Math.min(FALL, ic.vy + G*dt); ic.y += ic.vy*dt;
          if (solidAt(Math.floor(ic.x), Math.floor(ic.y + 0.8)) || ic.y > H){
            ic.state = 'gone'; burst(ic.x, ic.y + 0.7, [C.iceLight, C.ice]);
          } else if (p.x < ic.x + 0.2 && p.x + p.w > ic.x - 0.2 && p.y < ic.y + 0.8 && p.y + p.h > ic.y){
            ic.state = 'gone'; burst(ic.x, ic.y + 0.5, [C.iceLight, C.ice]);
            hurt(); if (state !== 'running') return;
          }
        }
      }
      if (p.x + p.w/2 >= L.goal + 1.2) win();
    }

    /* ---------- drawing ---------- */
    function ell(x, y, rx, ry, rot, fill, stroke){
      ctx.beginPath(); ctx.ellipse(x, y, Math.max(0.1,rx), Math.max(0.1,ry), rot || 0, 0, Math.PI*2);
      if (fill){ ctx.fillStyle = fill; ctx.fill(); }
      if (stroke){ ctx.strokeStyle = C.ink; ctx.lineWidth = stroke; ctx.stroke(); }
    }
    function drawBackground(c){
      ctx.fillStyle = C.sky; ctx.fillRect(0, 0, canvas.width, canvas.height);
      [[0.25, 7, C.hill, 4.2], [0.5, 5, C.hill2, 2.6]].forEach(([par, gap, col, base]) => {
        const off = cam*par, k0 = Math.floor(off/gap) - 1;
        for (let k=k0; k<k0 + Math.ceil(VW/gap) + 3; k++){
          const hgt = base + ((k*37 % 5) + 5) % 5 * 0.45;
          ell((k*gap - off)*c, (H - 1.2)*c, gap*0.75*c, hgt*c, 0, col);
        }
      });
    }
    function drawTile(ch, x, y, px, py, c){
      const lw = Math.max(1, c*0.06), key = x + ',' + y;
      if (ch === '#' || ch === 'I'){
        const ice = ch === 'I';
        ctx.fillStyle = ice ? C.ice : C.dirt; ctx.fillRect(px - 0.5, py - 0.5, c + 1, c + 1);
        ctx.fillStyle = ice ? C.iceDark : C.dirtDot;
        const sd = (x*7 + y*13) % 5;
        if (ice){
          ctx.fillRect(px + c*(0.15 + sd*0.1), py + c*0.55, c*0.3, c*0.06);
          ctx.fillRect(px + c*(0.55 - sd*0.06), py + c*0.8, c*0.2, c*0.05);
        } else {
          ctx.fillRect(px + c*(0.2 + sd*0.1), py + c*0.55, c*0.1, c*0.1);
          ctx.fillRect(px + c*(0.7 - sd*0.08), py + c*0.8, c*0.08, c*0.08);
        }
        if (y > 0 && !solidAt(x, y-1)){
          if (ice){
            ctx.fillStyle = C.iceLight; ctx.fillRect(px - 0.5, py, c + 1, c*0.2);
          } else {
            ctx.fillStyle = C.grass; ctx.fillRect(px - 0.5, py, c + 1, c*0.3);
            ctx.fillStyle = C.grassLight; ctx.fillRect(px - 0.5, py, c + 1, c*0.1);
            ctx.fillStyle = C.grass;
            for (let k=0; k<3; k++) ctx.fillRect(px + c*(0.15 + k*0.32), py - c*0.1, c*0.07, c*0.12);
          }
        }
      } else if (ch === '='){
        ctx.fillStyle = C.wood; ctx.fillRect(px + lw/2, py + lw/2, c - lw, c - lw);
        ctx.strokeStyle = C.ink; ctx.lineWidth = lw; ctx.strokeRect(px + lw/2, py + lw/2, c - lw, c - lw);
        ctx.strokeStyle = C.woodDark; ctx.beginPath();
        ctx.moveTo(px + c*0.1, py + c*0.5); ctx.lineTo(px + c*0.9, py + c*0.5);
        ctx.moveTo(px + c*0.15, py + c*0.15); ctx.lineTo(px + c*0.85, py + c*0.85);
        ctx.stroke();
      } else if (ch === 'C'){
        const cr = L.crumbles[key];
        const sx = cr && cr.state === 'shake' && !reduceMotion ? (Math.random() - 0.5)*c*0.08 : 0;
        ctx.fillStyle = C.crumble; ctx.fillRect(px + sx + lw/2, py + lw/2, c - lw, c*0.7);
        ctx.strokeStyle = C.ink; ctx.lineWidth = lw; ctx.strokeRect(px + sx + lw/2, py + lw/2, c - lw, c*0.7);
        ctx.strokeStyle = C.crumbleDark; ctx.beginPath();
        ctx.moveTo(px + sx + c*0.3, py + c*0.05); ctx.lineTo(px + sx + c*0.42, py + c*0.35); ctx.lineTo(px + sx + c*0.3, py + c*0.68);
        ctx.moveTo(px + sx + c*0.7, py + c*0.1); ctx.lineTo(px + sx + c*0.62, py + c*0.4);
        ctx.stroke();
      } else if (ch === 'S'){
        const k = L.springs[key] ? 0.45 : 1;
        const base = py + c, topY = py + c - c*0.85*k;
        ctx.fillStyle = C.ink; ctx.fillRect(px + c*0.1, base - c*0.12, c*0.8, c*0.12);
        ctx.strokeStyle = C.ink; ctx.lineWidth = Math.max(1.5, c*0.07); ctx.beginPath();
        const n = 4, h = (base - c*0.12) - (topY + c*0.18);
        ctx.moveTo(px + c*0.5, base - c*0.12);
        for (let i=1; i<=n; i++) ctx.lineTo(px + c*(i % 2 ? 0.25 : 0.75), base - c*0.12 - h*i/n);
        ctx.lineTo(px + c*0.5, topY + c*0.18);
        ctx.stroke();
        ctx.fillStyle = C.spring; ctx.fillRect(px + c*0.08, topY, c*0.84, c*0.2);
        ctx.strokeStyle = C.ink; ctx.lineWidth = lw; ctx.strokeRect(px + c*0.08, topY, c*0.84, c*0.2);
      } else if (ch === 'L' || ch === 'U'){
        const bump = L.bumps[key] ? Math.sin((0.2 - L.bumps[key])/0.2*Math.PI)*c*0.22 : 0;
        const by = py - bump;
        ctx.fillStyle = ch === 'L' ? C.clover : C.woodDark;
        ctx.fillRect(px + lw/2, by + lw/2, c - lw, c - lw);
        ctx.strokeStyle = C.ink; ctx.lineWidth = lw; ctx.strokeRect(px + lw/2, by + lw/2, c - lw, c - lw);
        if (ch === 'L'){
          const pulse = reduceMotion ? 0.9 : 0.75 + 0.25*Math.sin(clock*4 + x);
          ctx.globalAlpha = pulse;
          const cx = px + c*0.5, cy = by + c*0.46, r = c*0.12;
          ctx.fillStyle = C.cloverLight;
          [[-1,-1],[1,-1],[-1,1],[1,1]].forEach(([a,b]) => { ctx.beginPath(); ctx.arc(cx + a*r*0.95, cy + b*r*0.95, r, 0, Math.PI*2); ctx.fill(); });
          ctx.strokeStyle = C.cloverLight; ctx.lineWidth = Math.max(1, c*0.05);
          ctx.beginPath(); ctx.moveTo(cx, cy + r); ctx.quadraticCurveTo(cx + r*0.5, cy + r*2.3, cx + r*1.4, cy + r*2.6); ctx.stroke();
          ctx.globalAlpha = 1;
        } else {
          ctx.fillStyle = C.ink;
          [[0.2,0.2],[0.8,0.2],[0.2,0.8],[0.8,0.8]].forEach(([a,b]) => ctx.fillRect(px + c*a - c*0.04, by + c*b - c*0.04, c*0.08, c*0.08));
        }
      } else if (ch === '^'){
        ctx.fillStyle = C.spike; ctx.strokeStyle = C.ink; ctx.lineWidth = lw;
        for (let k=0; k<3; k++){
          ctx.beginPath();
          ctx.moveTo(px + k*c/3, py + c); ctx.lineTo(px + k*c/3 + c/6, py + c*0.42); ctx.lineTo(px + (k+1)*c/3, py + c);
          ctx.closePath(); ctx.fill(); ctx.stroke();
        }
      }
    }
    function drawTiles(c){
      const x0 = Math.floor(cam);
      for (let x=x0; x<=x0 + VW + 1; x++) for (let y=0; y<H; y++){
        const ch = tile(x,y); if (ch === ' ') continue;
        drawTile(ch, x, y, (x - cam)*c, y*c, c);
      }
    }
    function drawPlatforms(c){
      const lw = Math.max(1, c*0.06);
      L.platforms.forEach(pl => {
        const px = (pl.x - cam)*c, py = pl.y*c, w = pl.w*c, h = pl.h*c;
        if (px > canvas.width || px + w < 0) return;
        ctx.fillStyle = C.wood; ctx.fillRect(px, py, w, h);
        ctx.strokeStyle = C.ink; ctx.lineWidth = lw; ctx.strokeRect(px, py, w, h);
        ctx.fillStyle = C.woodDark; ctx.fillRect(px + lw, py + h*0.6, w - lw*2, h*0.3);
        ctx.fillStyle = C.ink;
        for (let k=0; k<Math.round(pl.w); k++) ctx.fillRect(px + (k + 0.5)*c*pl.w/Math.round(pl.w) - c*0.03, py + h*0.25, c*0.06, c*0.06);
      });
    }
    function drawApple(cx, cy, s){
      const r = s*0.32;
      const g = ctx.createRadialGradient(cx - r*0.35, cy - r*0.35, r*0.1, cx, cy, r*1.25);
      g.addColorStop(0, C.apple); g.addColorStop(1, C.appleDark);
      ctx.fillStyle = g; ctx.beginPath();
      ctx.ellipse(cx - r*0.32, cy, r*0.72, r*0.86, 0, 0, Math.PI*2);
      ctx.ellipse(cx + r*0.32, cy, r*0.72, r*0.86, 0, 0, Math.PI*2); ctx.fill();
      ell(cx - r*0.45, cy - r*0.32, r*0.15, r*0.26, -0.4, 'rgba(255,255,255,.4)');
      ctx.strokeStyle = C.stem; ctx.lineWidth = Math.max(1.5, r*0.16); ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(cx, cy - r*0.65); ctx.quadraticCurveTo(cx + r*0.05, cy - r*1.0, cx + r*0.22, cy - r*1.15); ctx.stroke();
      ctx.fillStyle = C.leaf; ctx.beginPath();
      ctx.moveTo(cx + r*0.12, cy - r*0.92); ctx.quadraticCurveTo(cx + r*0.55, cy - r*1.45, cx + r*0.95, cy - r*1.05);
      ctx.quadraticCurveTo(cx + r*0.5, cy - r*0.7, cx + r*0.12, cy - r*0.92); ctx.fill();
    }
    function drawLantern(l, c){
      const gx = (l.x + 0.5 - cam)*c, gy = L.groundTop(l.x)*c, lw = Math.max(1, c*0.06);
      if (l.lit) ell(gx, gy - c*1.45, c*0.6, c*0.6, 0, 'rgba(242,201,76,.28)');
      ctx.fillStyle = C.ink; ctx.fillRect(gx - c*0.05, gy - c*1.3, c*0.1, c*1.3);
      ctx.fillStyle = l.lit ? C.lampOn : C.lampOff;
      ctx.fillRect(gx - c*0.17, gy - c*1.65, c*0.34, c*0.38);
      ctx.strokeStyle = C.ink; ctx.lineWidth = lw; ctx.strokeRect(gx - c*0.17, gy - c*1.65, c*0.34, c*0.38);
      ctx.fillStyle = C.ink; ctx.fillRect(gx - c*0.22, gy - c*1.72, c*0.44, c*0.09);
    }
    function drawGoal(c){
      const gx = (L.goal - cam)*c, gy = L.groundTop(L.goal)*c;
      ell(gx + c*1.6, gy + c*0.06, c*1.7, c*0.34, 0, C.water, Math.max(1, c*0.05));
      const rip = reduceMotion ? 0 : Math.sin(clock*2.5)*c*0.08;
      ell(gx + c*0.9 + rip, gy + c*0.08, c*0.35, c*0.06, 0, C.waterLight);
      ell(gx + c*2.4 - rip, gy + c*0.02, c*0.28, c*0.05, 0, C.waterLight);
      ell(gx + c*1.7, gy - c*0.02, c*0.55, c*0.17, 0, C.pad, Math.max(1, c*0.04));
      ctx.fillStyle = C.water; ctx.beginPath(); ctx.moveTo(gx + c*1.7, gy - c*0.02); ctx.lineTo(gx + c*2.25, gy - c*0.1); ctx.lineTo(gx + c*2.25, gy + c*0.06); ctx.fill();
      ctx.fillStyle = C.flower;
      for (let k=0; k<5; k++){ const a = k/5*Math.PI*2; ell(gx + c*1.45 + Math.cos(a)*c*0.1, gy - c*0.16 + Math.sin(a)*c*0.06, c*0.08, c*0.06, a); }
      ell(gx + c*1.45, gy - c*0.16, c*0.05, c*0.05, 0, C.lampOn);
      ctx.strokeStyle = C.frogDark; ctx.lineWidth = Math.max(1.5, c*0.07); ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(gx + c*3.1, gy); ctx.lineTo(gx + c*3.0, gy - c*1.1);
      ctx.moveTo(gx + c*3.3, gy); ctx.lineTo(gx + c*3.4, gy - c*0.85);
      ctx.stroke();
      ell(gx + c*3.0, gy - c*1.1, c*0.07, c*0.2, 0, C.stem);
    }
    function drawIcicle(ic, c){
      if (ic.state === 'gone') return;
      const sx = ic.state === 'shake' && !reduceMotion ? (Math.random() - 0.5)*c*0.08 : 0;
      const x = (ic.x - cam)*c + sx, y = ic.y*c;
      ctx.fillStyle = C.ice; ctx.strokeStyle = C.ink; ctx.lineWidth = Math.max(1, c*0.05);
      ctx.beginPath(); ctx.moveTo(x - c*0.2, y); ctx.lineTo(x + c*0.2, y); ctx.lineTo(x, y + c*0.8); ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.fillStyle = C.iceLight; ctx.beginPath(); ctx.moveTo(x - c*0.1, y + c*0.05); ctx.lineTo(x - c*0.02, y + c*0.05); ctx.lineTo(x - c*0.02, y + c*0.45); ctx.closePath(); ctx.fill();
    }
    function drawBeetle(b, c){
      const bx = (b.x + b.w/2 - cam)*c, by = (b.y + b.h)*c, lw = Math.max(1, c*0.05);
      if (!b.alive){
        if (b.squash > 0){ ctx.globalAlpha = Math.min(1, b.squash*2); ell(bx, by - c*0.07, c*0.42, c*0.08, 0, C.beetle, lw); ctx.globalAlpha = 1; }
        return;
      }
      const f = Math.sign(b.vx) || 1;
      ctx.save(); ctx.translate(bx, by); ctx.scale(f, 1);
      ctx.strokeStyle = C.ink; ctx.lineWidth = lw; ctx.lineCap = 'round';
      const ph = reduceMotion ? 0 : Math.sin(b.anim*14)*c*0.06;
      ctx.beginPath();
      [-0.22, 0, 0.22].forEach((k, i) => { const o = (i % 2 ? ph : -ph); ctx.moveTo(k*c, -c*0.15); ctx.lineTo(k*c + o, 0); });
      ctx.stroke();
      ell(c*0.32, -c*0.2, c*0.13, c*0.12, 0, C.ink);
      ell(c*0.36, -c*0.23, c*0.035, c*0.035, 0, C.eye);
      ctx.beginPath(); ctx.ellipse(0, -c*0.13, c*0.36, c*0.36, 0, Math.PI, Math.PI*2); ctx.closePath();
      ctx.fillStyle = C.beetle; ctx.fill(); ctx.strokeStyle = C.ink; ctx.lineWidth = lw; ctx.stroke();
      ctx.beginPath(); ctx.moveTo(0, -c*0.49); ctx.lineTo(0, -c*0.13); ctx.stroke();
      ell(-c*0.15, -c*0.34, c*0.08, c*0.04, -0.5, C.shine);
      ctx.restore();
    }
    function drawFly(f, c){
      const x = (f.x - cam)*c, y = f.y*c, lw = Math.max(1, c*0.045);
      if (!f.alive){
        if (f.squash > 0){ ctx.globalAlpha = Math.min(1, f.squash*2); ell(x, y, c*0.25, c*0.07, 0, C.ink); ctx.globalAlpha = 1; }
        return;
      }
      const flap = reduceMotion ? 0.5 : (Math.sin(clock*40 + f.x) + 1)/2;
      const face = Math.cos(f.t*0.9) >= 0 ? 1 : -1;
      ctx.globalAlpha = 0.75;
      ell(x - c*0.08, y - c*0.18 - flap*c*0.06, c*0.16, c*0.09, -0.6, '#e8f0f2', lw*0.8);
      ell(x + c*0.08, y - c*0.18 - flap*c*0.06, c*0.16, c*0.09, 0.6, '#e8f0f2', lw*0.8);
      ctx.globalAlpha = 1;
      ell(x, y, c*0.22, c*0.16, 0, '#2c2a35', lw);
      ell(x + face*c*0.17, y - c*0.03, c*0.06, c*0.06, 0, '#d24a4a');
    }
    function drawFrog(c){
      if (p.inv > 0 && state === 'running' && Math.floor(clock*11) % 2 === 0 && !shield) return;
      const cx = (p.x + p.w/2 - cam)*c, by = (p.y + p.h)*c, s = c, lw = Math.max(1, s*0.05);
      ctx.save(); ctx.translate(cx, by);
      if (p.dead) ctx.rotate(Math.PI*(0.9 - deathT));
      ctx.scale(p.face, 1);
      const air = !p.onGround;
      let sx = 1, sy = 1;
      if (air){ sy = 1 + Math.min(0.15, Math.abs(p.vy)*0.01); sx = 1/sy; }
      else if (Math.abs(p.vx) > 0.5 && !reduceMotion){ const k = Math.sin(p.anim*3.2)*0.07; sy = 1 + k; sx = 1 - k; }
      ctx.scale(sx, sy);
      if (air) ell(-s*0.36, -s*0.1, s*0.24, s*0.07, 0.5, C.frogDark, lw);
      else ell(-s*0.24, -s*0.1, s*0.18, s*0.11, 0, C.frogDark, lw);
      ell(0, -s*0.32, s*0.38, s*0.29, 0, superT > 0 ? '#7cbf3f' : C.frog, lw);
      ell(s*0.1, -s*0.24, s*0.2, s*0.15, 0, C.belly);
      ell(s*0.2, -s*0.04, s*0.11, s*0.05, 0, C.frogDark, lw);
      [-s*0.04, s*0.22].forEach(ex => {
        ell(ex, -s*0.6, s*0.13, s*0.13, 0, C.frog, lw);
        if (p.dead){
          ctx.strokeStyle = C.ink; ctx.lineWidth = lw*1.3; const k = s*0.06;
          ctx.beginPath(); ctx.moveTo(ex-k, -s*0.6-k); ctx.lineTo(ex+k, -s*0.6+k); ctx.moveTo(ex+k, -s*0.6-k); ctx.lineTo(ex-k, -s*0.6+k); ctx.stroke();
        } else {
          ell(ex, -s*0.6, s*0.085, s*0.085, 0, C.eye);
          ell(ex + s*0.03, -s*0.6, s*0.045, s*0.05, 0, C.ink);
        }
      });
      ctx.strokeStyle = C.ink; ctx.lineWidth = lw; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.arc(s*0.2, -s*0.36, s*0.1, 0.15*Math.PI, 0.65*Math.PI); ctx.stroke();
      ctx.restore();
      if (shield && !p.dead){
        const r = s*0.62 + (reduceMotion ? 0 : Math.sin(clock*5)*s*0.03);
        ctx.fillStyle = 'rgba(220,240,255,.2)'; ctx.strokeStyle = 'rgba(236,248,255,.9)'; ctx.lineWidth = Math.max(1.5, s*0.05);
        ctx.beginPath(); ctx.arc(cx, by - s*0.42, r, 0, Math.PI*2); ctx.fill(); ctx.stroke();
        ctx.strokeStyle = 'rgba(255,255,255,.9)';
        ctx.beginPath(); ctx.arc(cx, by - s*0.42, r*0.75, 1.15*Math.PI, 1.4*Math.PI); ctx.stroke();
      }
      if (superT > 0 && !p.dead && !reduceMotion && Math.floor(clock*8) % 2 === 0){
        ctx.fillStyle = C.lampOn;
        ell(cx - s*0.35, by - s*0.05, s*0.05, s*0.05, 0, C.lampOn);
        ell(cx + s*0.38, by - s*0.2, s*0.04, s*0.04, 0, C.lampOn);
      }
    }
    function drawDarkness(c){
      if (dark.width !== canvas.width || dark.height !== canvas.height){ dark.width = canvas.width; dark.height = canvas.height; }
      dctx.globalCompositeOperation = 'source-over';
      dctx.clearRect(0, 0, dark.width, dark.height);
      dctx.fillStyle = 'rgba(6,10,20,0.8)'; dctx.fillRect(0, 0, dark.width, dark.height);
      dctx.globalCompositeOperation = 'destination-out';
      const light = (x, y, r) => {
        const gx = (x - cam)*c, gy = y*c, rr = r*c;
        if (gx < -rr || gx > dark.width + rr) return;
        const g = dctx.createRadialGradient(gx, gy, 0, gx, gy, rr);
        g.addColorStop(0, 'rgba(0,0,0,1)'); g.addColorStop(0.5, 'rgba(0,0,0,.8)'); g.addColorStop(1, 'rgba(0,0,0,0)');
        dctx.fillStyle = g; dctx.beginPath(); dctx.arc(gx, gy, rr, 0, Math.PI*2); dctx.fill();
      };
      light(p.x + p.w/2, p.y + p.h/2, 3.8);
      L.lanterns.forEach(l => light(l.x + 0.5, L.groundTop(l.x) - 1.45, l.lit ? 3.2 : 1.0));
      L.apples.forEach(a => { if (!a.got) light(a.x, a.y, 0.7); });
      L.fireflies.forEach(f => {
        const fx = f.x + Math.sin(clock*0.7 + f.ph)*0.6, fy = f.y + Math.sin(clock*1.3 + f.ph)*0.4;
        light(fx, fy, 0.9 + 0.3*Math.sin(clock*3 + f.ph));
      });
      const x0 = Math.floor(cam);
      for (let x=x0; x<=x0 + VW + 1; x++) for (let y=0; y<H; y++) if (tile(x,y) === 'L') light(x + 0.5, y + 0.5, 1.3);
      light(L.goal + 1.6, L.groundTop(L.goal) - 0.3, 2.4);
      ctx.drawImage(dark, 0, 0);
      L.fireflies.forEach(f => {
        const fx = f.x + Math.sin(clock*0.7 + f.ph)*0.6, fy = f.y + Math.sin(clock*1.3 + f.ph)*0.4;
        ctx.globalAlpha = 0.6 + 0.4*Math.sin(clock*3 + f.ph);
        ell((fx - cam)*c, fy*c, c*0.05, c*0.05, 0, '#f6e98a');
      });
      ctx.globalAlpha = 1;
    }
    function drawText(text, x, y, size){
      ctx.font = '700 ' + Math.round(size) + 'px Fredoka, system-ui, sans-serif';
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.lineWidth = Math.max(2, size*0.22); ctx.strokeStyle = C.dark ? '#0d1422' : '#ffffff';
      ctx.strokeText(text, x, y);
      ctx.fillStyle = C.dark ? '#f4f1dc' : C.ink; ctx.fillText(text, x, y);
    }
    function draw(){
      if (!L) return;
      const c = canvas.height / H;
      VW = canvas.width / c;
      drawBackground(c);
      drawTiles(c);
      drawPlatforms(c);
      drawGoal(c);
      L.lanterns.forEach(l => drawLantern(l, c));
      L.apples.forEach(a => { if (!a.got) drawApple((a.x - cam)*c, (a.y + (reduceMotion ? 0 : Math.sin(clock*3.3 + a.x)*0.06))*c, c); });
      L.icicles.forEach(ic => drawIcicle(ic, c));
      L.beetles.forEach(b => drawBeetle(b, c));
      L.flies.forEach(f => drawFly(f, c));
      drawFrog(c);
      particles.forEach(q => { ctx.globalAlpha = Math.max(0, q.life); ell((q.x - cam)*c, q.y*c, c*0.07, c*0.07, 0, q.color); });
      ctx.globalAlpha = 1;
      if (C.dark) drawDarkness(c);
      L.popups.forEach(q => { ctx.globalAlpha = Math.min(1, q.t*2); drawText(q.text, (q.x - cam)*c, q.y*c, c*0.3); });
      ctx.globalAlpha = 1;
      const status = [];
      if (shield) status.push('Blase');
      if (superT > 0) status.push('Sprung ' + Math.ceil(superT));
      if (status.length){
        ctx.save(); ctx.textAlign = 'left';
        status.forEach((t, i) => {
          ctx.font = '700 ' + Math.round(c*0.28) + 'px Fredoka, system-ui, sans-serif';
          ctx.textBaseline = 'middle'; ctx.lineWidth = Math.max(2, c*0.06);
          ctx.strokeStyle = C.dark ? '#0d1422' : '#ffffff'; ctx.strokeText(t, c*0.3, c*(0.45 + i*0.4));
          ctx.fillStyle = C.dark ? '#f4f1dc' : C.ink; ctx.fillText(t, c*0.3, c*(0.45 + i*0.4));
        });
        ctx.restore();
      }
    }
    function update(now, dt){
      if (state === 'idle' || state === 'start') return;
      if (state === 'running' || state === 'dying'){
        acc = Math.min(acc + dt/1000, 0.1);
        while (acc >= STEP && (state === 'running' || state === 'dying')){ tick(STEP); acc -= STEP; }
      }
      draw();
    }

    /* ---------- input ---------- */
    function jumpPress(){ if (!jumpHeld){ jumpHeld = true; jumpBuffer = 0.12; } }
    function dirPress(name){
      if (state === 'start'){ if (name === 'up') levelList.move(-1); if (name === 'down') levelList.move(1); return; }
      if (state !== 'running' && state !== 'dying') return;
      if (name === 'left') hold.left = true;
      if (name === 'right') hold.right = true;
      if (name === 'up') jumpPress();
    }
    function dirRelease(name){
      if (name === 'left') hold.left = false;
      if (name === 'right') hold.right = false;
      if (name === 'up') jumpHeld = false;
    }
    function a(){
      if (state === 'start'){ const btn = $('frogList').querySelectorAll('button')[levelList.index]; if (btn) btn.click(); }
      else if (state === 'running' || state === 'dying') jumpPress();
      else if (state === 'paused') resume();
      else if (state === 'won' || state === 'over') $('fPrimary').click();
    }
    function aRelease(){ jumpHeld = false; }
    function b(){
      if (state === 'start') goHome();
      else if (state === 'running') pause();
      else if (state !== 'dying') openStart();
    }
    function pauseKey(){ if (state === 'running') pause(); else if (state === 'paused') resume(); }

    $('fPrimary').addEventListener('click', () => {
      if (state === 'paused') resume();
      else if (state === 'won' && levelIdx + 1 < LEVELS.length) startLevel(levelIdx + 1);
      else startLevel(levelIdx);
    });
    $('fMenu').addEventListener('click', openStart);

    return { openStart, leave, dirPress, dirRelease, a, aRelease, b, pauseKey, update, pause, clearHold,
             _debug: () => ({ L, p, state, lives, applesGot }) };
  })();

  /* =================== INPUT ROUTING =================== */
  function route(fnName, arg){
    if (app === 'home'){
      if (fnName === 'dirPress'){
        const d = (arg === 'left' || arg === 'up') ? -1 : 1;
        homeIndex = (homeIndex + d + tiles.length) % tiles.length;
        tiles[homeIndex].focus();
      }
      if (fnName === 'a') GAMES[homeIndex].open();
      return;
    }
    const target = app === 'snake' ? Snake : app === 'rps' ? RPS : Frog;
    if (target[fnName]) target[fnName](arg);
  }

  const CODEMAP = { ArrowUp:'up', ArrowDown:'down', ArrowLeft:'left', ArrowRight:'right', KeyW:'up', KeyS:'down', KeyA:'left', KeyD:'right' };
  document.addEventListener('keydown', ev => {
    const d = CODEMAP[ev.code];
    if (d){ ev.preventDefault(); route('dirPress', d); return; }
    const onButton = document.activeElement && document.activeElement.tagName === 'BUTTON';
    if (ev.code === 'Enter' || ev.code === 'NumpadEnter' || ev.code === 'Space'){
      if (onButton) return;
      ev.preventDefault(); route('a'); return;
    }
    if (ev.code === 'Escape' || ev.code === 'Backspace'){ ev.preventDefault(); route('b'); return; }
    if (ev.code === 'KeyP'){ ev.preventDefault(); if (app === 'snake') Snake.pauseKey(); if (app === 'frog') Frog.pauseKey(); return; }
    if (ev.code === 'KeyH'){ ev.preventDefault(); goHome(); return; }
    const dig = { Digit1:0, Digit2:1, Digit3:2, Numpad1:0, Numpad2:1, Numpad3:2 }[ev.code];
    if (dig !== undefined && app === 'rps'){ ev.preventDefault(); RPS.digit(dig); }
  });

  document.addEventListener('keyup', ev => {
    const d = CODEMAP[ev.code];
    if (d) route('dirRelease', d);
    if (ev.code === 'Space' || ev.code === 'Enter' || ev.code === 'NumpadEnter') route('aRelease');
  });
  window.addEventListener('blur', () => Frog.clearHold());

  function bindButton(el, fn, rel){
    el.addEventListener('pointerdown', ev => { ev.preventDefault(); fn(); });
    el.addEventListener('click', ev => { if (ev.detail === 0){ fn(); if (rel) rel(); } });
    if (rel) ['pointerup','pointercancel','pointerleave'].forEach(t => el.addEventListener(t, rel));
  }
  document.querySelectorAll('.dpad button').forEach(b => bindButton(b, () => route('dirPress', b.dataset.dir), () => route('dirRelease', b.dataset.dir)));
  bindButton($('aBtn'), () => route('a'), () => route('aRelease'));
  bindButton($('bBtn'), () => route('b'));
  bindButton($('pauseBtn'), () => { if (app === 'snake') Snake.pauseKey(); if (app === 'frog') Frog.pauseKey(); });
  bindButton($('homeBtn'), goHome);

  let t0 = null;
  screenEl.addEventListener('touchstart', ev => { const t = ev.touches[0]; t0 = { x:t.clientX, y:t.clientY }; }, { passive:true });
  screenEl.addEventListener('touchmove', ev => {
    if (app !== 'snake' || !Snake.isRunning()) return;
    ev.preventDefault();
    if (!t0) return;
    const t = ev.touches[0], dx = t.clientX - t0.x, dy = t.clientY - t0.y;
    if (Math.max(Math.abs(dx), Math.abs(dy)) > 22){
      Snake.dirPress(Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 'right' : 'left') : (dy > 0 ? 'down' : 'up'));
      t0 = { x:t.clientX, y:t.clientY };
    }
  }, { passive:false });
  screenEl.addEventListener('touchend', () => { t0 = null; });

  document.addEventListener('visibilitychange', () => { if (!document.hidden) return; if (app === 'snake') Snake.pause(); if (app === 'frog') Frog.pause(); });
  window.addEventListener('resize', resizeCanvas);
  if (window.ResizeObserver) new ResizeObserver(resizeCanvas).observe(screenEl);

  let lastFrame = 0;
  function frame(now){
    const dt = lastFrame ? Math.min(100, now - lastFrame) : 0;
    lastFrame = now;
    if (app === 'snake') Snake.update(now, dt);
    if (app === 'frog') Frog.update(now, dt);
    requestAnimationFrame(frame);
  }

  if (document.fonts && document.fonts.ready) document.fonts.ready.then(resizeCanvas);
  goHome();
  requestAnimationFrame(frame);

  if ('serviceWorker' in navigator && location.protocol === 'https:'){
    window.addEventListener('load', () => { navigator.serviceWorker.register('sw.js').catch(() => {}); });
  }
})();
