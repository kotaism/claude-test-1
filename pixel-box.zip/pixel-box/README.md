# Pixel-Box

Drei kleine Browserspiele in einer Web-App:

- **Snake** mit sechs Modi (Klassisch, Ohne Wände, Unendlich, Turbo, Felsen, Zeitrennen)
- **Schere Stein Papier** gegen einen Bot oder zu zweit an einem Gerät
- **Froschsprung**, ein Jump & Run mit fünf Leveln und Kleeblöcken

Alles läuft direkt im Browser, ohne Build-Schritt und ohne Server. Rekorde und Fortschritt werden im `localStorage` des Browsers gespeichert.

## Auf GitHub Pages veröffentlichen

1. Neues Repository auf GitHub anlegen, zum Beispiel `pixel-box`.
2. Alle Dateien aus diesem Ordner ins Repository hochladen (auch die versteckte Datei `.nojekyll`). Am einfachsten über „Add file“ → „Upload files“ oder per Git:
   ```bash
   git init
   git add .
   git commit -m "Pixel-Box"
   git branch -M main
   git remote add origin https://github.com/DEIN-NAME/pixel-box.git
   git push -u origin main
   ```
3. Im Repository unter **Settings → Pages** bei „Build and deployment“ die Quelle **Deploy from a branch** wählen, Branch **main** und Ordner **/ (root)**, dann speichern.
4. Nach ein bis zwei Minuten ist die Seite erreichbar unter `https://DEIN-NAME.github.io/pixel-box/`.

## Lokal testen

Die Seite funktioniert auch per Doppelklick auf `index.html`. Für den Offline-Modus und die App-Installation braucht es einen Webserver, zum Beispiel:

```bash
python3 -m http.server 8000
```

und dann `http://localhost:8000` öffnen.

## Als App installieren

Auf GitHub Pages lässt sich die Pixel-Box am Handy über „Zum Home-Bildschirm hinzufügen“ installieren und danach auch offline spielen.

## Updates

Nach Änderungen an den Dateien in `sw.js` die Versionsnummer in `CACHE` erhöhen (z. B. `pixel-box-v2`), damit Besucher die neue Version bekommen.

## Dateien

| Datei | Inhalt |
|---|---|
| `index.html` | Seitenstruktur |
| `style.css` | Gestaltung, heller und dunkler Modus |
| `app.js` | Alle drei Spiele |
| `sw.js` | Offline-Cache |
| `manifest.webmanifest`, `icons/` | App-Name und Icons |
